const firebaseConfig = {
    apiKey: "AIzaSyDjLNMkKywT5dyTErt9MwlL5HOiLre12vY",
    authDomain: "messenger-21d25.firebaseapp.com",
    databaseURL: "https://messenger-21d25.firebaseio.com",
    projectId: "messenger-21d25",
    storageBucket: "messenger-21d25.appspot.com",
    messagingSenderId: "711004761539",
    appId: "1:711004761539:web:e0fd080b6934f03318e176",
    measurementId: "G-7W7RHQPLP7"
  };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    var CLIENT_ID =
      '711004761539-njfgm0ifts7h9ibnhbegr540bb812nc8.apps.googleusercontent.com';